# pylint: disable=unused-import
from cdm._bundle import cdm_base_staticdata_party_NaturalPersonRole as NaturalPersonRole

# EOF
