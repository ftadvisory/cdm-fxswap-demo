# pylint: disable=unused-import
from cdm._bundle import cdm_base_staticdata_party_AncillaryEntity as AncillaryEntity

# EOF
