# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['ProductGradeEnum']

class ProductGradeEnum(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    """
    Identifies the grade of physical commodity product to be delivered.
    """
    ARABIAN_LIGHT = "Arabian-Light"
    """
    Applies to Oil Product Type Oil.
    """
    BRASS_BLEND = "Brass-Blend"
    """
    Applies to Oil Product Type Oil.
    """
    BRENT = "Brent"
    """
    Applies to Oil Product Type Oil.
    """
    CARBOB = "CARBOB"
    """
    Applies to Oil Product Type Gasoline.
    """
    CBOB = "CBOB"
    """
    Applies to Oil Product Type Gasoline.
    """
    COLD_LAKE = "Cold-Lake"
    """
    Applies to Oil Product Type Oil.
    """
    DUBAI = "Dubai"
    """
    Applies to Oil Product Type Oil.
    """
    EUROBOB = "EUROBOB"
    """
    Applies to Oil Product Type Gasoline.
    """
    EDMONTON_HIGH_SULPHUR_SOUR = "Edmonton-High-Sulphur-Sour"
    """
    Applies to Oil Product Type Oil.
    """
    GERMAN_10_PPM = "German-10PPM"
    """
    Applies to Oil Product Type Diesel Fuel.
    """
    GULF_COAST_SWEET = "Gulf-Coast-Sweet"
    """
    Applies to Oil Product Type Oil.
    """
    HARDISTY_LIGHT = "Hardisty-Light"
    """
    Applies to Oil Product Type Oil.
    """
    IRANIAN_LIGHT = "Iranian-Light"
    """
    Applies to Oil Product Type Oil.
    """
    IRANIAN_LIGHT_1 = "Iranian-Light"
    """
    Applies to Oil Product Type Oil.
    """
    JET = "Jet"
    """
    Applies to Oil Product Type Jet Fuel.
    """
    KIRKUK_LIGHT = "Kirkuk-Light"
    """
    Applies to Oil Product Type Oil.
    """
    KUWAIT = "Kuwait"
    """
    Applies to Oil Product Type Oil.
    """
    LIGHT_LOUISIANA_SWEET = "Light-Louisiana-Sweet"
    """
    Applies to Oil Product Type Oil.
    """
    LOW_SULPHUR = "Low-Sulphur"
    """
    Applies to Oil Product Type Diesel Fuel.
    """
    LOW_SULPHUR_JET = "Low-Sulphur-Jet"
    """
    Applies to Oil Product Type Jet Fuel.
    """
    MARS = "Mars"
    """
    Applies to Oil Product Type Oil.
    """
    MIXED_SOUR_BLEND = "Mixed-Sour-Blend"
    """
    Applies to Oil Product Type Oil.
    """
    MIXED_SWEET_BLEND = "Mixed-Sweet-Blend"
    """
    Applies to Oil Product Type Oil.
    """
    MURBAN = "Murban"
    """
    Applies to Oil Product Type Oil.
    """
    NATURAL_GASOLINE = "Natural-Gasoline"
    """
    Applies to Oil Product Type Gasoline.
    """
    NO_2 = "No.-2"
    """
    Applies to Oil Product Type Diesel Fuel.
    """
    NO_6_0_3_PERCENT = "No.-6-0.3-Percent"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    NO_6_0_3_PERCENT_HP = "No.-6-0.3-Percent-HP"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    NO_6_0_3_PERCENT_LP = "No.-6-0.3-Percent-LP"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    NO_6_0_7_PERCENT = "No.-6-0.7-Percent"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    NO_6_1_0_PERCENT = "No.-6-1.0-Percent"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    NO_6_2_2_PERCENT = "No.-6-2.2-Percent"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    NO_6_3_PERCENT = "No.-6-3-Percent"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    NORMAL_BUTANE = "Normal-Butane"
    """
    Applies to Oil Product Type Butane.
    """
    NORTH_DAKOTA_LIGHT = "North-Dakota-Light"
    """
    Applies to Oil Product Type Oil.
    """
    OMAN = "Oman"
    """
    Applies to Oil Product Type Oil.
    """
    POLYMER_GRADE = "Polymer-Grade"
    """
    Applies to Oil Product Type Propylene.
    """
    RBOB = "RBOB"
    """
    Applies to Oil Product Type Gasoline.
    """
    SAHARAN = "Saharan"
    """
    Applies to Oil Product Type Oil.
    """
    SOUR = "Sour"
    """
    Applies to Oil Product Type Oil.
    """
    SOUTHERN_GREEN_CANYON = "Southern-Green-Canyon"
    """
    Applies to Oil Product Type Oil.
    """
    TAPIS = "Tapis"
    """
    Applies to Oil Product Type Oil.
    """
    THUNDER_HORSE = "Thunder-Horse"
    """
    Applies to Oil Product Type Oil.
    """
    US_REGULAR_UNLEADED = "US-Regular-Unleaded"
    """
    Applies to Oil Product Type Gasoline.
    """
    ULTRA_LOW_SULPHUR = "Ultra-Low-Sulphur"
    """
    Applies to Oil Product Type Diesel Fuel.
    """
    URALS = "Urals"
    """
    Applies to Oil Product Type Oil.
    """
    URALS_SOUR = "Urals-Sour"
    """
    Applies to Oil Product Type Oil.
    """
    WTI = "WTI"
    """
    Applies to Oil Product Type Oil.
    """
    WTS = "WTS"
    """
    Applies to Oil Product Type Oil.
    """
    WESTERN_CANADIAN_SELECT = "Western-Canadian-Select"
    """
    Applies to Oil Product Type Oil.
    """
    ZUETINA = "Zuetina"
    """
    Applies to Oil Product Type Oil.
    """
    _0_1_PERCENT = "0.1-Percent"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    _0_5_PERCENT = "0.5-Percent"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    _10_PPM = "10-PPM"
    """
    Applies to Oil Product Type Gasoline.
    """
    _10_PPM_95_R = "10-PPM-95-R"
    """
    Applies to Oil Product Type Gasoline.
    """
    _10_PPM_PREMIUM_UNLEADED = "10-PPM-Premium-Unleaded"
    """
    Applies to Oil Product Type Gasoline.
    """
    _10_PPM_REGULAR_UNLEADED = "10-PPM-Regular-Unleaded"
    """
    Applies to Oil Product Type Gasoline.
    """
    _180_CST = "180-CST"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    _1_0_PERCENT = "1.0-Percent"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    _380_CST = "380-CST"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    _3_5_PERCENT = "3.5-Percent"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    _50_PPM = "50-PPM"
    """
    Applies to Oil Product Type Fuel Oil.
    """
    _54 = "54"
    """
    Applies to Oil Product Type Jet Fuel.
    """
    _55 = "55"
    """
    Applies to Oil Product Type Jet Fuel.
    """
    _87_M = "87-M"
    """
    Applies to Oil Product Type Gasoline.
    """
    _87_UNLEADED = "87-Unleaded"
    """
    Applies to Oil Product Type Gasoline.
    """
    _87_UNLEADED_ULS_30 = "87-Unleaded-ULS-30"
    """
    Applies to Oil Product Type Gasoline.
    """
    _92_UNLEADED = "92-Unleaded"
    """
    Applies to Oil Product Type Gasoline.
    """
    _93_UNLEADED = "93-Unleaded"
    """
    Applies to Oil Product Type Gasoline.
    """
    _95_UNLEADED = "95-Unleaded"
    """
    Applies to Oil Product Type Gasoline.
    """
    _97_UNLEADED = "97-Unleaded"
    """
    Applies to Oil Product Type Gasoline.
    """
    _98_UNLEADED = "98-Unleaded"
    """
    Applies to Oil Product Type Gasoline.
    """
