# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['MoneyMarketTypeEnum']

class MoneyMarketTypeEnum(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    CERTIFICATE_OF_DEPOSIT = "CertificateOfDeposit"
    COMMERCIAL_PAPER = "CommercialPaper"
