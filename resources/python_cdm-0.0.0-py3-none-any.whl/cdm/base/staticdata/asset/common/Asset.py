# pylint: disable=unused-import
from cdm._bundle import cdm_base_staticdata_asset_common_Asset as Asset

# EOF
