# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.staticdata.asset.common.AssetIdTypeEnum import AssetIdTypeEnum
from cdm.base.staticdata.asset.common.AssetIdentifier import AssetIdentifier

__all__ = ['AssetIdentifierByType']


@replaceable
def AssetIdentifierByType(identifiers: list[AssetIdentifier] | None, idType: AssetIdTypeEnum) -> AssetIdentifier:
    """
    Returns all the Asset Identifiers of a certain Identifier Type.
    
    Parameters 
    ----------
    identifiers : AssetIdentifier
    
    idType : AssetIdTypeEnum
    
    Returns
    -------
    filteredIdentifier : AssetIdentifier
    
    """
    self = inspect.currentframe()
    
    
    filteredIdentifier = rune_filter(rune_resolve_attr(self, "identifiers"), lambda item: rune_all_elements(rune_resolve_attr(item, "identifierType"), "=", rune_resolve_attr(self, "idType")))
    
    
    return filteredIdentifier

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
