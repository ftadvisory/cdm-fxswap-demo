# pylint: disable=unused-import
from cdm._bundle import cdm_base_staticdata_asset_credit_NotDomesticCurrency as NotDomesticCurrency

# EOF
