# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['RoundingFrequencyEnum']

class RoundingFrequencyEnum(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    """
    How often is rounding performed
    """
    DAILY = "Daily"
    """
    Rounding is done on each day
    """
    PERIOD_END = "PeriodEnd"
    """
    Rounding is done only at the end of the period
    """
