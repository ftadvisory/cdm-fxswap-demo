# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.datetime.functions.BusinessCenterHolidays import BusinessCenterHolidays
from cdm.base.datetime.BusinessCenterEnum import BusinessCenterEnum

__all__ = ['BusinessCenterHolidaysMultiple']


@replaceable
def BusinessCenterHolidaysMultiple(businessCenters: list[BusinessCenterEnum] | None) -> datetime.date:
    """
    Returns a merged list of holidays for the supplied business centers.
    
    Parameters 
    ----------
    businessCenters : BusinessCenterEnum
    The business centers for which the holiday list is required.
    
    Returns
    -------
    holidayDates : date
    
    """
    self = inspect.currentframe()
    
    
    holidayDates = (lambda item: sorted(item))((lambda item: set(item))((lambda item: rune_flatten_list(item))(list(map(lambda item: BusinessCenterHolidays(item), rune_resolve_attr(self, "businessCenters"))))))
    
    
    return holidayDates

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
