# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *

__all__ = ['AppendDateToList']


@replaceable
def AppendDateToList(origDates: list[datetime.date] | None, newDate: datetime.date) -> datetime.date:
    """
    Add a date to a list of dates.
    
    Parameters 
    ----------
    origDates : date
    List of dates.
    
    newDate : date
    Date to add to the list.
    
    Returns
    -------
    newList : date
    
    """
    self = inspect.currentframe()
    
    
    newList =  rune_resolve_attr(self, "origDates")
    newList.add_rune_attr(self, rune_resolve_attr(self, "newDate"))
    
    
    return newList

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
