# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *

__all__ = ['ToTime']


@replaceable
def ToTime(hours: int, minutes: int, seconds: int) -> datetime.time:
    """
    Implemented by Java function.
    
    Parameters 
    ----------
    hours : int
    
    minutes : int
    
    seconds : int
    
    Returns
    -------
    time : time
    
    """
    self = inspect.currentframe()
    
    
    time = rune_resolve_attr(self, "time")
    
    
    return time

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
