# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['PeriodEnum']

class PeriodEnum(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    """
    The enumerated values to specify the period, e.g. day, week.
    """
    D = "D"
    """
    Day
    """
    M = "M"
    """
    Month
    """
    W = "W"
    """
    Week
    """
    Y = "Y"
    """
    Year
    """
