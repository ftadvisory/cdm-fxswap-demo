# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['DayOfWeekEnum']

class DayOfWeekEnum(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    """
    The enumerated values to specify a day of the seven-day week.
    """
    FRI = "FRI"
    """
    Friday
    """
    MON = "MON"
    """
    Monday
    """
    SAT = "SAT"
    """
    Saturday
    """
    SUN = "SUN"
    """
    Sunday
    """
    THU = "THU"
    """
    Thursday
    """
    TUE = "TUE"
    """
    Tuesday
    """
    WED = "WED"
    """
    Wednesday
    """
