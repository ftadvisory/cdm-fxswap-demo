# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.math.functions.Min import Min
from cdm.base.math.functions.Max import Max
from cdm.base.math.ArithmeticOperationEnum import ArithmeticOperationEnum

__all__ = ['ArithmeticOperation']


@replaceable
def ArithmeticOperation(n1: Decimal, op: ArithmeticOperationEnum, n2: Decimal) -> Decimal:
    """
    
    Parameters 
    ----------
    n1 : number
    
    op : ArithmeticOperationEnum
    
    n2 : number
    
    Returns
    -------
    result : number
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn5():
        return Min(rune_resolve_attr(self, "n1"), rune_resolve_attr(self, "n2"))
    
    def _else_fn5():
        return True
    
    def _then_fn4():
        return Max(rune_resolve_attr(self, "n1"), rune_resolve_attr(self, "n2"))
    
    def _else_fn4():
        return if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.ArithmeticOperationEnum.ArithmeticOperationEnum.MIN), _then_fn5, _else_fn5)
    
    def _then_fn3():
        return (rune_resolve_attr(self, "n1") / rune_resolve_attr(self, "n2"))
    
    def _else_fn3():
        return if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.ArithmeticOperationEnum.ArithmeticOperationEnum.MAX), _then_fn4, _else_fn4)
    
    def _then_fn2():
        return (rune_resolve_attr(self, "n1") * rune_resolve_attr(self, "n2"))
    
    def _else_fn2():
        return if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.ArithmeticOperationEnum.ArithmeticOperationEnum.DIVIDE), _then_fn3, _else_fn3)
    
    def _then_fn1():
        return (rune_resolve_attr(self, "n1") - rune_resolve_attr(self, "n2"))
    
    def _else_fn1():
        return if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.ArithmeticOperationEnum.ArithmeticOperationEnum.MULTIPLY), _then_fn2, _else_fn2)
    
    def _then_fn0():
        return (rune_resolve_attr(self, "n1") + rune_resolve_attr(self, "n2"))
    
    def _else_fn0():
        return if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.ArithmeticOperationEnum.ArithmeticOperationEnum.SUBTRACT), _then_fn1, _else_fn1)
    
    result =  if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.ArithmeticOperationEnum.ArithmeticOperationEnum.ADD), _then_fn0, _else_fn0)
    
    
    return result

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
