# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.math.functions.StringEquals import StringEquals
from cdm.base.math.UnitType import UnitType

__all__ = ['UnitEquals']


@replaceable
def UnitEquals(u1: UnitType | None, u2: UnitType | None) -> bool:
    """
    Compares two UnitType to check if all attributes match.
    
    Parameters 
    ----------
    u1 : UnitType
    
    u2 : UnitType
    
    Returns
    -------
    result : boolean
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn0():
        return StringEquals(rune_resolve_attr(rune_resolve_attr(self, "u1"), "currency"), rune_resolve_attr(rune_resolve_attr(self, "u2"), "currency"))
    
    def _else_fn0():
        return rune_all_elements(rune_resolve_attr(self, "u1"), "=", rune_resolve_attr(self, "u2"))
    
    result =  if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(self, "u1"), "currency")), _then_fn0, _else_fn0)
    
    
    return result

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
