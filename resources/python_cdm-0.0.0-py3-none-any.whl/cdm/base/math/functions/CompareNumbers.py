# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.math.CompareOp import CompareOp

__all__ = ['CompareNumbers']


@replaceable
def CompareNumbers(n1: Decimal, op: CompareOp, n2: Decimal) -> bool:
    """
    
    Parameters 
    ----------
    n1 : number
    
    op : CompareOp
    
    n2 : number
    
    Returns
    -------
    result : boolean
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn4():
        return rune_all_elements(rune_all_elements(rune_resolve_attr(self, "n1"), "<", rune_resolve_attr(self, "n2")), "=", True)
    
    def _else_fn4():
        return False
    
    def _then_fn3():
        return rune_all_elements(rune_all_elements(rune_resolve_attr(self, "n1"), "<=", rune_resolve_attr(self, "n2")), "=", True)
    
    def _else_fn3():
        return if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.CompareOp.CompareOp.LESS_THAN), _then_fn4, _else_fn4)
    
    def _then_fn2():
        return rune_all_elements(rune_all_elements(rune_resolve_attr(self, "n1"), "=", rune_resolve_attr(self, "n2")), "=", True)
    
    def _else_fn2():
        return if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.CompareOp.CompareOp.LESS_THAN_OR_EQUALS), _then_fn3, _else_fn3)
    
    def _then_fn1():
        return rune_all_elements(rune_all_elements(rune_resolve_attr(self, "n1"), ">=", rune_resolve_attr(self, "n2")), "=", True)
    
    def _else_fn1():
        return if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.CompareOp.CompareOp.EQUALS), _then_fn2, _else_fn2)
    
    def _then_fn0():
        return rune_all_elements(rune_all_elements(rune_resolve_attr(self, "n1"), ">", rune_resolve_attr(self, "n2")), "=", True)
    
    def _else_fn0():
        return if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.CompareOp.CompareOp.GREATER_THAN_OR_EQUALS), _then_fn1, _else_fn1)
    
    result =  if_cond_fn(rune_all_elements(rune_resolve_attr(self, "op"), "=", cdm.base.math.CompareOp.CompareOp.GREATER_THAN), _then_fn0, _else_fn0)
    
    
    return result

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
