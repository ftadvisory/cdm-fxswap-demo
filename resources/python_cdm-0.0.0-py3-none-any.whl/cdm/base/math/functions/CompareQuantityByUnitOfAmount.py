# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.math.CompareOp import CompareOp
from cdm.base.math.functions.FilterQuantity import FilterQuantity
from cdm.base.math.functions.CompareNumbers import CompareNumbers
from cdm.base.math.Quantity import Quantity
from cdm.base.math.UnitType import UnitType

__all__ = ['CompareQuantityByUnitOfAmount']


@replaceable
def CompareQuantityByUnitOfAmount(quantity1: list[Quantity] | None, op: CompareOp, quantity2: list[Quantity] | None, unitOfAmount: UnitType) -> bool:
    """
    
    Parameters 
    ----------
    quantity1 : Quantity
    
    op : CompareOp
    
    quantity2 : Quantity
    
    unitOfAmount : UnitType
    
    Returns
    -------
    result : boolean
    
    """
    self = inspect.currentframe()
    
    
    result =  (lambda item: rune_all_elements(rune_flatten_list(item), "=", True))(list(map(lambda item: list(map(lambda item: CompareNumbers(rune_resolve_attr(rune_resolve_attr(self, "q1"), "value"), rune_resolve_attr(self, "op"), rune_resolve_attr(rune_resolve_attr(self, "q2"), "value")), FilterQuantity(rune_resolve_attr(self, "quantity2"), rune_resolve_attr(self, "unitOfAmount")))), FilterQuantity(rune_resolve_attr(self, "quantity1"), rune_resolve_attr(self, "unitOfAmount")))))
    
    
    return result

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
