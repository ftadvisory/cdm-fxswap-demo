# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.math.QuantityChangeDirectionEnum import QuantityChangeDirectionEnum

__all__ = ['UpdateAmount']


@replaceable
def UpdateAmount(oldAmount: Decimal | None, changeAmount: Decimal | None, direction: QuantityChangeDirectionEnum) -> Decimal:
    """
    Updates an amount based on the given QuantityChangeDirectionEnum.  If the direction is Increase, the old amount and change amount are summed, if the direction is Decrease, then the change amount is subtracted from the old amount, and if the direction is Replace then the change amount replaces the old amount.
    
    Parameters 
    ----------
    oldAmount : number
    
    changeAmount : number
    
    direction : QuantityChangeDirectionEnum
    
    Returns
    -------
    newAmount : number
    
    """
    self = inspect.currentframe()
    
    
    newAmount =      def _then_1():
            return (rune_resolve_attr(self, "oldAmount") + rune_resolve_attr(self, "changeAmount"))
        def _then_2():
            return (rune_resolve_attr(self, "oldAmount") - rune_resolve_attr(self, "changeAmount"))
        def _then_3():
            return rune_resolve_attr(self, "changeAmount")
        switchAttribute = rune_resolve_attr(self, "direction")
        if switchAttribute == rune_resolve_attr(cdm.base.math.QuantityChangeDirectionEnum.QuantityChangeDirectionEnum.INCREASE,"Increase"):
            return _then_1()
        elif switchAttribute == rune_resolve_attr(cdm.base.math.QuantityChangeDirectionEnum.QuantityChangeDirectionEnum.DECREASE,"Decrease"):
            return _then_2()
        elif switchAttribute == rune_resolve_attr(cdm.base.math.QuantityChangeDirectionEnum.QuantityChangeDirectionEnum.REPLACE,"Replace"):
            return _then_3()
    
    
    
    return newAmount

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
