# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['CompareOp']

class CompareOp(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    EQUALS = "Equals"
    GREATER_THAN = "GreaterThan"
    GREATER_THAN_OR_EQUALS = "GreaterThanOrEquals"
    LESS_THAN = "LessThan"
    LESS_THAN_OR_EQUALS = "LessThanOrEquals"
