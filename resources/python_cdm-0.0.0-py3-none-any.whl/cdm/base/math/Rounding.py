# pylint: disable=unused-import
from cdm._bundle import cdm_base_math_Rounding as Rounding

# EOF
