version = (0,0,0,0)
version_str = '0.0.0-0'
__version__ = '0.0.0'
__build_time__ = '2025-11-06T20:45:24.684287'