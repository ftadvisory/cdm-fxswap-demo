# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['ValuationSourceEnum']

class ValuationSourceEnum(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    """
    Source for the valuation of the transaction by the valuation party.
    """
    CENTRAL_COUNTERPARTY = "CentralCounterparty"
    """
    Central Counterparty's Valuation
    """
