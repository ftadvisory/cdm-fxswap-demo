# pylint: disable=unused-import
from cdm._bundle import cdm_event_common_ContractDetails as ContractDetails

# EOF
