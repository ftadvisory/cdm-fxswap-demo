# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['RecordAmountTypeEnum']

class RecordAmountTypeEnum(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    """
    The enumeration of the account level for the billing summary.
    """
    ACCOUNT_TOTAL = "AccountTotal"
    GRAND_TOTAL = "GrandTotal"
    PARENT_TOTAL = "ParentTotal"
