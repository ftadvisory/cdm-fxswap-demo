# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.math.functions.FilterQuantityByFinancialUnit import FilterQuantityByFinancialUnit
from cdm.event.common.QuantityChangeInstruction import QuantityChangeInstruction
from cdm.base.math.QuantityChangeDirectionEnum import QuantityChangeDirectionEnum
from cdm.base.math.NonNegativeQuantitySchedule import NonNegativeQuantitySchedule
from cdm.event.common.TradeState import TradeState
from cdm.base.math.UnitType import UnitType
from cdm.base.math.FinancialUnitEnum import FinancialUnitEnum
from cdm.observable.asset.Price import Price
from cdm.observable.asset.PriceQuantity import PriceQuantity
from cdm.event.common.PrimitiveInstruction import PrimitiveInstruction
from cdm.event.common.functions.Create_TradeState import Create_TradeState
from cdm.event.common.StockSplitInstruction import StockSplitInstruction

__all__ = ['Create_StockSplit']


@replaceable
def Create_StockSplit(stockSplitInstruction: StockSplitInstruction, before: TradeState) -> TradeState:
    """
    Function specification to create the fully-formed business event which represents the impact of a stock split (or a reverse stock split) on an Equity Derivatives contract on a certain date.
    
    Parameters 
    ----------
    stockSplitInstruction : StockSplitInstruction
    
    before : TradeState
    
    Returns
    -------
    after : TradeState
    
    """
    self = inspect.currentframe()
    
    
    preSplitNumberOfShares = rune_resolve_attr(rune_get_only_element(FilterQuantityByFinancialUnit(rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "before"), "trade"), "tradeLot")), "priceQuantity"), "quantity"), cdm.base.math.FinancialUnitEnum.FinancialUnitEnum.SHARE)), "value")
    postSplitNumberOfShares = NonNegativeQuantitySchedule(value=(rune_resolve_attr(self, "preSplitNumberOfShares") * rune_resolve_attr(rune_resolve_attr(self, "stockSplitInstruction"), "adjustmentRatio")), unit=UnitType(financialUnit=cdm.base.math.FinancialUnitEnum.FinancialUnitEnum.SHARE))
    preSplitPrice = (lambda item: rune_get_only_element(item))(rune_filter(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "before"), "trade"), "tradeLot"), "priceQuantity"), "price"), lambda item: rune_all_elements(rune_resolve_attr(rune_resolve_attr(item, "perUnitOf"), "financialUnit"), "=", cdm.base.math.FinancialUnitEnum.FinancialUnitEnum.SHARE)))
    postSplitPrice = Price(value=(rune_resolve_attr(rune_resolve_attr(self, "preSplitPrice"), "value") / rune_resolve_attr(rune_resolve_attr(self, "stockSplitInstruction"), "adjustmentRatio")), unit=rune_resolve_attr(rune_resolve_attr(self, "preSplitPrice"), "unit"), perUnitOf=rune_resolve_attr(rune_resolve_attr(self, "preSplitPrice"), "perUnitOf"), priceType=rune_resolve_attr(rune_resolve_attr(self, "preSplitPrice"), "priceType"), priceExpression=rune_resolve_attr(rune_resolve_attr(self, "preSplitPrice"), "priceExpression"), composite=rune_resolve_attr(rune_resolve_attr(self, "preSplitPrice"), "composite"), arithmeticOperator=rune_resolve_attr(rune_resolve_attr(self, "preSplitPrice"), "arithmeticOperator"), cashPrice=rune_resolve_attr(rune_resolve_attr(self, "preSplitPrice"), "cashPrice"), datedValue=[])
    postSplitPriceQuantity = PriceQuantity(price=rune_resolve_attr(self, "postSplitPrice"), quantity=rune_resolve_attr(self, "postSplitNumberOfShares"))
    quantityChangeInstruction = QuantityChangeInstruction(change=rune_resolve_attr(self, "postSplitPriceQuantity"), direction=cdm.base.math.QuantityChangeDirectionEnum.QuantityChangeDirectionEnum.REPLACE, lotIdentifier=[])
    primitiveInstruction = PrimitiveInstruction(quantityChange=rune_resolve_attr(self, "quantityChangeInstruction"))
    after =  Create_TradeState(rune_resolve_attr(self, "primitiveInstruction"), rune_resolve_attr(self, "before"))
    
    
    return after

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
