# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.product.template.PerformancePayout import PerformancePayout
from cdm.base.datetime.functions.ResolveAdjustableDate import ResolveAdjustableDate
from cdm.event.common.functions.AdjustedValuationDates import AdjustedValuationDates
from cdm.observable.event.ObservationIdentifier import ObservationIdentifier
from cdm.event.common.functions.ResolvePerformanceValuationTime import ResolvePerformanceValuationTime

__all__ = ['ResolvePerformanceObservationIdentifiers']


@replaceable
def ResolvePerformanceObservationIdentifiers(payout: PerformancePayout, adjustedDate: datetime.date) -> ObservationIdentifier:
    """
    Defines which attributes on the PerformancePayout should be used to locate and resolve the underlier's price, for example for the reset process.
    
    Parameters 
    ----------
    payout : PerformancePayout
    
    adjustedDate : date
    
    Returns
    -------
    identifiers : ObservationIdentifier
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn0():
        return rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "payout"), "valuationDates"), "interimValuationDate")
    
    def _else_fn0():
        return rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "payout"), "valuationDates"), "finalValuationDate")
    
    adjustedFinalValuationDate = ResolveAdjustableDate(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "payout"), "valuationDates"), "finalValuationDate"), "valuationDate"))
    valuationDates = if_cond_fn(rune_all_elements(rune_resolve_attr(self, "adjustedDate"), "<", rune_resolve_attr(self, "adjustedFinalValuationDate")), _then_fn0, _else_fn0)
    identifiers = _get_rune_object('ObservationIdentifier', 'observable', rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "payout"), "underlier"), "Observable"))
    identifiers = set_rune_attr(rune_resolve_attr(self, 'identifiers'), 'observationDate', (lambda item: item[-1])(rune_filter(AdjustedValuationDates(rune_resolve_attr(rune_resolve_attr(self, "payout"), "valuationDates")), lambda item: rune_all_elements(item, "<=", rune_resolve_attr(self, "adjustedDate")))))
    identifiers = set_rune_attr(rune_resolve_attr(self, 'identifiers'), 'observationTime', ResolvePerformanceValuationTime(rune_resolve_attr(rune_resolve_attr(self, "valuationDates"), "valuationTime"), rune_resolve_attr(rune_resolve_attr(self, "valuationDates"), "valuationTimeType"), rune_get_only_element(rune_resolve_deep_attr(self, "identifier")), rune_resolve_attr(rune_resolve_attr(self, "valuationDates"), "determinationMethod")))
    identifiers = set_rune_attr(rune_resolve_attr(self, 'identifiers'), 'informationSource', rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "payout"), "observationTerms"), "informationSource"), "primarySource"))
    identifiers = set_rune_attr(rune_resolve_attr(self, 'identifiers'), 'determinationMethodology->determinationMethod', rune_resolve_attr(rune_resolve_attr(self, "valuationDates"), "determinationMethod"))
    
    
    return identifiers

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
