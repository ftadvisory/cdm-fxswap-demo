# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.position.PositionStatusEnum import PositionStatusEnum
from cdm.event.common.TradeState import TradeState
from cdm.event.common.ContractFormationInstruction import ContractFormationInstruction

__all__ = ['Create_ContractFormation']


@replaceable
def Create_ContractFormation(instruction: ContractFormationInstruction, execution: TradeState) -> TradeState:
    """
    Function specification that represents an executed trade for a contractual product that has been affirmed (or confirmed) by the two parties. The formed contract can reference a legal agreement for instance a master agreement, by using the optional legalAgreement input.
    
    Parameters 
    ----------
    instruction : ContractFormationInstruction
    Instructions to be used as an input to the function
    
    execution : TradeState
    
    Returns
    -------
    contractFormation : TradeState
    
    """
    self = inspect.currentframe()
    
    
    contractFormation =  rune_resolve_attr(self, "execution")
    contractFormation.add_rune_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, contractFormation), 'trade'), 'contractDetails'), 'documentation'), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "legalAgreement"))
    contractFormation = _get_rune_object('TradeState', 'state', _get_rune_object('State', 'positionState', cdm.event.position.PositionStatusEnum.PositionStatusEnum.FORMED))
    
    
    return contractFormation

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
