# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.TradeState import TradeState
from cdm.event.common.ObservationInstruction import ObservationInstruction

__all__ = ['Create_Observation']


@replaceable
def Create_Observation(instruction: ObservationInstruction, before: TradeState) -> TradeState:
    """
    Function specification to create an observation that incorporates an observation event into the observation history of a given trade state.
    
    Parameters 
    ----------
    instruction : ObservationInstruction
    
    before : TradeState
    Specifies the trade to be updated.
    
    Returns
    -------
    after : TradeState
    
    """
    self = inspect.currentframe()
    
    
    after =  rune_resolve_attr(self, "before")
    after.add_rune_attr(rune_resolve_attr(rune_resolve_attr(self, after), 'observationHistory'), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "observationEvent"))
    
    
    return after

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
