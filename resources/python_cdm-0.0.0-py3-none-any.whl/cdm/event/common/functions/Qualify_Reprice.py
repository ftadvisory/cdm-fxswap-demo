# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.functions.FilterOpenTradeStates import FilterOpenTradeStates
from cdm.event.common.functions.ExtractTradePurchasePrice import ExtractTradePurchasePrice
from cdm.event.common.functions.ExtractTradeCollateralQuantity import ExtractTradeCollateralQuantity
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.ExtractOpenEconomicTerms import ExtractOpenEconomicTerms
from cdm.event.common.functions.ExtractBeforeTrade import ExtractBeforeTrade
from cdm.event.common.functions.ExtractAfterTrade import ExtractAfterTrade
from cdm.event.common.functions.ExtractTradeCollateralPrice import ExtractTradeCollateralPrice
from cdm.event.common.functions.FilterClosedTradeStates import FilterClosedTradeStates
from cdm.event.common.functions.ExtractBeforeEconomicTerms import ExtractBeforeEconomicTerms

__all__ = ['Qualify_Reprice']


@replaceable
def Qualify_Reprice(businessEvent: BusinessEvent) -> bool:
    """
    This qualification function is used to qualify repricing of a contractual product with an interest rate payout and assetPayout.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    openTrades = rune_resolve_attr(FilterOpenTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after")), "trade")
    closedTradeState = FilterClosedTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"))
    beforeTrade = ExtractBeforeTrade(rune_resolve_attr(self, "businessEvent"))
    afterTrade = ExtractAfterTrade(rune_resolve_attr(self, "businessEvent"))
    beforeTradePurchasePrice = ExtractTradePurchasePrice(rune_resolve_attr(self, "beforeTrade"))
    afterTradePurchasePrice = ExtractTradePurchasePrice(rune_resolve_attr(self, "afterTrade"))
    beforeTradeCollateralQuantity = ExtractTradeCollateralQuantity(rune_resolve_attr(self, "beforeTrade"))
    afterTradeCollateralQuantity = ExtractTradeCollateralQuantity(rune_resolve_attr(self, "afterTrade"))
    beforeTradeCollateralPrice = ExtractTradeCollateralPrice(rune_resolve_attr(self, "beforeTrade"))
    afterTradeCollateralPrice = ExtractTradeCollateralPrice(rune_resolve_attr(self, "afterTrade"))
    beforeEconomicterms = ExtractBeforeEconomicTerms(rune_resolve_attr(self, "businessEvent"))
    openEconomicTerms = ExtractOpenEconomicTerms(rune_resolve_attr(self, "businessEvent"))
    is_event =  ((((((((((rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"), "trade"), "product"), "economicTerms"), "payout"), "InterestRatePayout")) and rune_all_elements(rune_count(rune_resolve_attr(self, "openTrades")), "=", 1)) and rune_all_elements(rune_count(rune_resolve_attr(self, "closedTradeState")), "=", 1)) and rune_attr_exists(rune_resolve_attr(self, "beforeTradePurchasePrice"))) and rune_attr_exists(rune_resolve_attr(self, "afterTradePurchasePrice"))) and rune_any_elements(rune_resolve_attr(self, "afterTradePurchasePrice"), "<>", rune_resolve_attr(self, "beforeTradePurchasePrice"))) and rune_all_elements(rune_resolve_attr(self, "beforeTradeCollateralQuantity"), "=", rune_resolve_attr(self, "afterTradeCollateralQuantity"))) and rune_any_elements(rune_resolve_attr(self, "beforeTradeCollateralPrice"), "<>", rune_resolve_attr(self, "afterTradeCollateralPrice"))) and rune_attr_exists(rune_resolve_attr(self, "beforeEconomicterms"))) and rune_attr_exists(rune_resolve_attr(self, "openEconomicTerms"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "terminationDate"), "=", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "terminationDate")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
