# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.functions.FilterOpenTradeStates import FilterOpenTradeStates
from cdm.event.common.BusinessEvent import BusinessEvent

__all__ = ['Qualify_OnDemandPayment']


@replaceable
def Qualify_OnDemandPayment(businessEvent: BusinessEvent) -> bool:
    """
    Qualification of a on-demand payment.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    instruction = rune_get_only_element(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"))
    afterTradeStates = FilterOpenTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"))
    transfer = rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"), "primitiveInstruction"), "transfer"), "transferState"), "transfer")
    is_event =  ((((rune_all_elements(rune_count(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction")), "=", 1) and rune_all_elements(rune_count(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after")), "=", 1)) and rune_all_elements(rune_count(rune_resolve_attr(self, "afterTradeStates")), "=", 1)) and rune_check_one_of(self, rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "primitiveInstruction"), "transfer"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "transfer"), "transferExpression"), "scheduledTransfer"), "transferType"), "=", cdm.product.common.settlement.ScheduledTransferEnum.ScheduledTransferEnum.NET_INTEREST))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
