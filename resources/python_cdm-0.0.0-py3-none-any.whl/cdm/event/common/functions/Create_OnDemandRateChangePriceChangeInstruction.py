# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.observable.asset.PriceTypeEnum import PriceTypeEnum
from cdm.event.common.QuantityChangeInstruction import QuantityChangeInstruction
from cdm.base.math.QuantityChangeDirectionEnum import QuantityChangeDirectionEnum
from cdm.observable.asset.Price import Price
from cdm.observable.asset.PriceQuantity import PriceQuantity

__all__ = ['Create_OnDemandRateChangePriceChangeInstruction']


@replaceable
def Create_OnDemandRateChangePriceChangeInstruction(priceQuantity: list[PriceQuantity], newRate: Decimal) -> QuantityChangeInstruction:
    """
    Creates a price change instruction for an on-demand rate change, based on a new rate provided as a single number by matching it to a single rate price.
    
    Parameters 
    ----------
    priceQuantity : PriceQuantity
    The original price / quantity to be modified with the new rate.
    
    newRate : number
    The new rate value, provided as a single number.
    
    Returns
    -------
    quantityChangeInstruction : QuantityChangeInstruction
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rune_local_condition(_pre_registry)
    def condition_0_OneRatePrice(self):
        """
        There should be 1 and only 1 rate type price in the current price.
        """
        return rune_attr_exists(rune_resolve_attr(self, "currentRatePrice"))
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    currentRatePrice = (lambda item: rune_get_only_element(item))((lambda item: rune_filter(item, lambda item: rune_all_elements(rune_resolve_attr(item, "priceType"), "=", cdm.observable.asset.PriceTypeEnum.PriceTypeEnum.INTEREST_RATE)))((lambda item: rune_flatten_list(item))(list(map(lambda item: rune_resolve_attr(item, "price"), rune_resolve_attr(self, "priceQuantity"))))))
    newPrice = Price(value=rune_resolve_attr(self, "newRate"), unit=rune_resolve_attr(rune_resolve_attr(self, "currentRatePrice"), "unit"), perUnitOf=rune_resolve_attr(rune_resolve_attr(self, "currentRatePrice"), "perUnitOf"), priceType=rune_resolve_attr(rune_resolve_attr(self, "currentRatePrice"), "priceType"), priceExpression=rune_resolve_attr(rune_resolve_attr(self, "currentRatePrice"), "priceExpression"), composite=rune_resolve_attr(rune_resolve_attr(self, "currentRatePrice"), "composite"), arithmeticOperator=rune_resolve_attr(rune_resolve_attr(self, "currentRatePrice"), "arithmeticOperator"), cashPrice=rune_resolve_attr(rune_resolve_attr(self, "currentRatePrice"), "cashPrice"), datedValue=[])
    newPriceQuantity = PriceQuantity(price=rune_resolve_attr(self, "newPrice"))
    quantityChangeInstruction =  QuantityChangeInstruction(change=rune_resolve_attr(self, "newPriceQuantity"), direction=cdm.base.math.QuantityChangeDirectionEnum.QuantityChangeDirectionEnum.REPLACE, lotIdentifier=[])
    
    
    return quantityChangeInstruction

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
