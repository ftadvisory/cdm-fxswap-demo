# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.functions.FilterOpenTradeStates import FilterOpenTradeStates
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.NewTradeInstructionOnlyExists import NewTradeInstructionOnlyExists

__all__ = ['Qualify_PairOff']


@replaceable
def Qualify_PairOff(businessEvent: BusinessEvent) -> bool:
    """
    Qualifies an event as a pair-off when all the details of the existing trades are maintained, except for their execution details which are updated to include a package component. This package component must be unique across all trades.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    openTradeState = FilterOpenTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"))
    newTradeInstruction = rune_filter(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"), lambda item: NewTradeInstructionOnlyExists(rune_resolve_attr(item, "primitiveInstruction")))
    packageRef = rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "openTradeState"), "trade"), "executionDetails"), "packageReference")
    is_event =  (((((((rune_all_elements(rune_count(rune_resolve_attr(self, "newTradeInstruction")), "=", rune_count(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "openTradeState"), "trade"), "product"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "newTradeInstruction"), "before"), "trade"), "product"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "openTradeState"), "trade"), "tradeLot"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "newTradeInstruction"), "before"), "trade"), "tradeLot"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "openTradeState"), "trade"), "counterparty"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "newTradeInstruction"), "before"), "trade"), "counterparty"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "openTradeState"), "trade"), "ancillaryParty"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "newTradeInstruction"), "before"), "trade"), "ancillaryParty"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "openTradeState"), "trade"), "adjustment"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "newTradeInstruction"), "before"), "trade"), "adjustment"))) and rune_all_elements(rune_count(rune_resolve_attr(self, "packageRef")), "=", rune_count(rune_resolve_attr(self, "openTradeState")))) and rune_all_elements(rune_count(set(rune_resolve_attr(self, "packageRef"))), "=", 1))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
