# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.observable.asset.PriceTypeEnum import PriceTypeEnum
from cdm.event.common.functions.Create_TerminationInstruction import Create_TerminationInstruction
from cdm.event.common.QuantityChangeInstruction import QuantityChangeInstruction
from cdm.base.math.QuantityChangeDirectionEnum import QuantityChangeDirectionEnum
from cdm.base.math.NonNegativeQuantitySchedule import NonNegativeQuantitySchedule
from cdm.base.datetime.AdjustableOrRelativeDate import AdjustableOrRelativeDate
from cdm.event.common.TradeState import TradeState
from cdm.observable.asset.Price import Price
from cdm.event.common.functions.Create_EffectiveOrTerminationDateTermChangeInstruction import Create_EffectiveOrTerminationDateTermChangeInstruction
from cdm.observable.asset.PriceQuantity import PriceQuantity
from cdm.event.common.PrimitiveInstruction import PrimitiveInstruction

__all__ = ['Create_AdjustmentPrimitiveInstruction']


@replaceable
def Create_AdjustmentPrimitiveInstruction(tradeState: TradeState, newAllinPrice: Decimal, newAssetQuantity: Decimal, effectiveRepriceDate: AdjustableOrRelativeDate) -> PrimitiveInstruction:
    """
    Creates the primitive instructions for a repricing that alters the collateral quantity and value of the trade. Transaction value and variation margin are processed separately as are transfers of cash and securities.
    
    Parameters 
    ----------
    tradeState : TradeState
    The original trade state and trade to be repriced.
    
    newAllinPrice : number
    The collateral new all-in price.
    
    newAssetQuantity : number
    The collateral new quantity.
    
    effectiveRepriceDate : AdjustableOrRelativeDate
    The date to reprice the collateral
    
    Returns
    -------
    instruction : PrimitiveInstruction
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rune_local_condition(_pre_registry)
    def condition_0_SingleTradeLot(self):
        """
        This repricing function applies only to trades with a single lot.
        """
        return rune_all_elements(rune_count(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "tradeLot")), "=", 1)
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    oldPriceQuantity = rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "tradeLot"), "priceQuantity")
    currentAssetPrice = (lambda item: rune_get_only_element(item))((lambda item: rune_filter(item, lambda item: rune_all_elements(rune_resolve_attr(item, "priceType"), "=", cdm.observable.asset.PriceTypeEnum.PriceTypeEnum.ASSET_PRICE)))((lambda item: rune_flatten_list(item))(list(map(lambda item: rune_resolve_attr(item, "price"), rune_resolve_attr(self, "oldPriceQuantity"))))))
    newPrice = Price(value=rune_resolve_attr(self, "newAllinPrice"), unit=rune_resolve_attr(rune_resolve_attr(self, "currentAssetPrice"), "unit"), perUnitOf=rune_resolve_attr(rune_resolve_attr(self, "currentAssetPrice"), "perUnitOf"), priceType=rune_resolve_attr(rune_resolve_attr(self, "currentAssetPrice"), "priceType"), priceExpression=rune_resolve_attr(rune_resolve_attr(self, "currentAssetPrice"), "priceExpression"), composite=rune_resolve_attr(rune_resolve_attr(self, "currentAssetPrice"), "composite"), arithmeticOperator=rune_resolve_attr(rune_resolve_attr(self, "currentAssetPrice"), "arithmeticOperator"), cashPrice=rune_resolve_attr(rune_resolve_attr(self, "currentAssetPrice"), "cashPrice"), datedValue=[])
    changeQuantity = (lambda item: set(item))(list(map(lambda item: NonNegativeQuantitySchedule(value=rune_resolve_attr(self, "newAssetQuantity"), unit=rune_resolve_attr(item, "unit")), rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "tradeLot")), "priceQuantity"), "quantity"))))
    newPriceQuantity = PriceQuantity(price=[rune_resolve_attr(self, "newPrice")], quantity=rune_resolve_attr(self, "changeQuantity"))
    instruction = _get_rune_object('PrimitiveInstruction', 'split', _get_rune_object('SplitInstruction', 'breakdown', [Create_TerminationInstruction(rune_resolve_attr(self, "tradeState"))]))
    instruction.add_rune_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, instruction), 'split'), 'breakdown'), [PrimitiveInstruction(quantityChange=QuantityChangeInstruction(change=[rune_resolve_attr(self, "newPriceQuantity")], direction=cdm.base.math.QuantityChangeDirectionEnum.QuantityChangeDirectionEnum.REPLACE, lotIdentifier=[]), termsChange=Create_EffectiveOrTerminationDateTermChangeInstruction(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "product"), rune_resolve_attr(self, "effectiveRepriceDate"), []))])
    
    
    return instruction

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
