# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.ExtractOpenEconomicTerms import ExtractOpenEconomicTerms
from cdm.event.common.functions.ExtractBeforeEconomicTerms import ExtractBeforeEconomicTerms

__all__ = ['Qualify_Substitution']


@replaceable
def Qualify_Substitution(businessEvent: BusinessEvent) -> bool:
    """
    Qualification of a collateral substitution event.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    beforeEconomicterms = ExtractBeforeEconomicTerms(rune_resolve_attr(self, "businessEvent"))
    openEconomicTerms = ExtractOpenEconomicTerms(rune_resolve_attr(self, "businessEvent"))
    is_event =  (((((rune_attr_exists(rune_resolve_attr(self, "beforeEconomicterms")) and rune_attr_exists(rune_resolve_attr(self, "openEconomicTerms"))) and rune_any_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "payout"), "<>", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "payout"))) and rune_any_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "collateral"), "<>", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "collateral"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "effectiveDate"), "=", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "terminationDate"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "terminationDate"), "=", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "terminationDate")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
