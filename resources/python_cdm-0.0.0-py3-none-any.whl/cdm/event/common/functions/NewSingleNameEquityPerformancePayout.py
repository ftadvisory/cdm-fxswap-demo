# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.product.template.PerformancePayout import PerformancePayout
from cdm.legaldocumentation.transaction.EquitySwapMasterConfirmation2018 import EquitySwapMasterConfirmation2018
from cdm.base.staticdata.asset.common.Security import Security
from cdm.base.staticdata.asset.common.InstrumentTypeEnum import InstrumentTypeEnum

__all__ = ['NewSingleNameEquityPerformancePayout']


@replaceable
def NewSingleNameEquityPerformancePayout(security: Security, masterConfirmation: EquitySwapMasterConfirmation2018 | None) -> PerformancePayout:
    """
    Function specification to create the equity payout part of an Equity Swap according to the 2018 ISDA CDM Equity Confirmation template.
    
    Parameters 
    ----------
    security : Security
    
    masterConfirmation : EquitySwapMasterConfirmation2018
    
    Returns
    -------
    performancePayout : PerformancePayout
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rune_local_condition(_pre_registry)
    def condition_0_EquitySecurityType(self):
        """
        Security must be equity (single name).
        """
        return rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "security"), "instrumentType"), "=", cdm.base.staticdata.asset.common.InstrumentTypeEnum.InstrumentTypeEnum.EQUITY)
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    performancePayout = _get_rune_object('PerformancePayout', 'returnTerms', _get_rune_object('ReturnTerms', 'priceReturnTerms', _get_rune_object('PriceReturnTerms', 'returnType', rune_resolve_attr(rune_resolve_attr(self, "masterConfirmation"), "typeOfSwapElection"))))
    performancePayout = set_rune_attr(rune_resolve_attr(self, 'performancePayout'), 'valuationDates', rune_resolve_attr(rune_resolve_attr(self, "masterConfirmation"), "valuationDates"))
    performancePayout = set_rune_attr(rune_resolve_attr(self, 'performancePayout'), 'paymentDates', rune_resolve_attr(rune_resolve_attr(self, "masterConfirmation"), "equityCashSettlementDates"))
    performancePayout = set_rune_attr(rune_resolve_attr(self, 'performancePayout'), 'settlementTerms', rune_resolve_attr(rune_resolve_attr(self, "masterConfirmation"), "settlementTerms"))
    
    
    return performancePayout

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
