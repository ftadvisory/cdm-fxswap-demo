# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.BillingInstruction import BillingInstruction
from cdm.event.common.functions.Create_BillingSummary import Create_BillingSummary
from cdm.event.common.functions.Create_BillingRecords import Create_BillingRecords
from cdm.event.common.SecurityLendingInvoice import SecurityLendingInvoice

__all__ = ['Create_SecurityLendingInvoice']


@replaceable
def Create_SecurityLendingInvoice(instruction: BillingInstruction) -> SecurityLendingInvoice:
    """
    Defines the process of calculating and creating a Security Lending Invoice.
    
    Parameters 
    ----------
    instruction : BillingInstruction
    Specifies the instructions for creation of a Security Lending billing invoice.
    
    Returns
    -------
    invoice : SecurityLendingInvoice
    
    """
    self = inspect.currentframe()
    
    
    invoice = _get_rune_object('SecurityLendingInvoice', 'sendingParty', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "sendingParty"))
    invoice = set_rune_attr(rune_resolve_attr(self, 'invoice'), 'receivingParty', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "receivingParty"))
    invoice = set_rune_attr(rune_resolve_attr(self, 'invoice'), 'billingStartDate', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "billingStartDate"))
    invoice = set_rune_attr(rune_resolve_attr(self, 'invoice'), 'billingEndDate', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "billingEndDate"))
    invoice.add_rune_attr(rune_resolve_attr(rune_resolve_attr(self, invoice), 'billingRecord'), Create_BillingRecords(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "billingRecordInstruction")))
    invoice.add_rune_attr(rune_resolve_attr(rune_resolve_attr(self, invoice), 'billingSummary'), Create_BillingSummary(rune_resolve_attr(rune_resolve_attr(self, "invoice"), "billingRecord")))
    
    
    return invoice

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
