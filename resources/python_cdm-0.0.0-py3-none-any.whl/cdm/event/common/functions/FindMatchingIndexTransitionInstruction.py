# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.observable.asset.PriceQuantity import PriceQuantity

__all__ = ['FindMatchingIndexTransitionInstruction']


@replaceable
def FindMatchingIndexTransitionInstruction(instructions: list[PriceQuantity], priceQuantity: PriceQuantity) -> PriceQuantity:
    """
    
    Parameters 
    ----------
    instructions : PriceQuantity
    
    priceQuantity : PriceQuantity
    
    Returns
    -------
    matchingInstruction : PriceQuantity
    
    """
    self = inspect.currentframe()
    
    
    matchingInstruction =  (lambda item: item[0])(rune_filter(rune_resolve_attr(self, "instructions"), lambda item: ((rune_all_elements(rune_resolve_attr(rune_resolve_deep_attr(self, "indexTenor"), "period"), "=", rune_resolve_attr(rune_resolve_deep_attr(self, "indexTenor"), "period")) and rune_all_elements(rune_resolve_attr(rune_resolve_deep_attr(self, "indexTenor"), "periodMultiplier"), "=", rune_resolve_attr(rune_resolve_deep_attr(self, "indexTenor"), "periodMultiplier"))) and (rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(item, "quantity"), "unit"), "currency"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "priceQuantity"), "quantity"), "unit"), "currency")) or rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(item, "price"), "unit"), "currency"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "priceQuantity"), "price"), "unit"), "currency"))))))
    
    
    return matchingInstruction

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
