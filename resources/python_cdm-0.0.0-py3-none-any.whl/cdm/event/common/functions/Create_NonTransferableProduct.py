# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.product.template.Underlier import Underlier
from cdm.base.staticdata.party.PayerReceiver import PayerReceiver
from cdm.product.template.NonTransferableProduct import NonTransferableProduct

__all__ = ['Create_NonTransferableProduct']


@replaceable
def Create_NonTransferableProduct(underlier: Underlier, payerReceiver: PayerReceiver) -> NonTransferableProduct:
    """
    Creates a NonTransferableProduct (ie EconomicTerms) from an underlier.
    
    Parameters 
    ----------
    underlier : Underlier
    
    payerReceiver : PayerReceiver
    
    Returns
    -------
    newProduct : NonTransferableProduct
    
    """
    self = inspect.currentframe()
    
    
    newProduct = _get_rune_object('NonTransferableProduct', 'economicTerms', _get_rune_object('EconomicTerms', 'payout', _get_rune_object('Payout', 'SettlementPayout', _get_rune_object('SettlementPayout', 'underlier', rune_resolve_attr(self, "underlier")))))
    newProduct = set_rune_attr(rune_resolve_attr(self, 'newProduct'), 'economicTerms->payout->SettlementPayout->payerReceiver', rune_resolve_attr(self, "payerReceiver"))
    
    
    return newProduct

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
