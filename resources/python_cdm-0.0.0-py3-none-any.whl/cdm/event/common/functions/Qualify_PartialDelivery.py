# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.functions.FilterOpenTradeStates import FilterOpenTradeStates
from cdm.event.common.functions.ExtractTradeCollateralQuantity import ExtractTradeCollateralQuantity
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.ExtractOpenEconomicTerms import ExtractOpenEconomicTerms
from cdm.event.common.functions.ExtractBeforeTrade import ExtractBeforeTrade
from cdm.event.common.functions.ExtractAfterTrade import ExtractAfterTrade
from cdm.event.common.functions.FilterClosedTradeStates import FilterClosedTradeStates
from cdm.event.common.functions.ExtractBeforeEconomicTerms import ExtractBeforeEconomicTerms

__all__ = ['Qualify_PartialDelivery']


@replaceable
def Qualify_PartialDelivery(businessEvent: BusinessEvent) -> bool:
    """
    Qualification of a partial delivery which constitutes a change in quantity and open with the remaining quantity and termination date.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    beforeEconomicterms = ExtractBeforeEconomicTerms(rune_resolve_attr(self, "businessEvent"))
    openEconomicTerms = ExtractOpenEconomicTerms(rune_resolve_attr(self, "businessEvent"))
    openTrades = rune_resolve_attr(FilterOpenTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after")), "trade")
    closedTradeState = FilterClosedTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"))
    beforeTrade = ExtractBeforeTrade(rune_resolve_attr(self, "businessEvent"))
    afterTrade = ExtractAfterTrade(rune_resolve_attr(self, "businessEvent"))
    beforeTradeCollateralQuantity = rune_get_only_element(ExtractTradeCollateralQuantity(rune_resolve_attr(self, "beforeTrade")))
    afterTradeCollateralQuantity = rune_get_only_element(ExtractTradeCollateralQuantity(rune_resolve_attr(self, "afterTrade")))
    is_event =  ((((((((rune_attr_exists(rune_resolve_attr(self, "beforeEconomicterms")) and rune_attr_exists(rune_resolve_attr(self, "openEconomicTerms"))) and rune_all_elements(rune_count(rune_resolve_attr(self, "openTrades")), "=", 1)) and rune_all_elements(rune_count(rune_resolve_attr(self, "closedTradeState")), "=", 1)) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "payout"), "InterestRatePayout"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "payout"), "InterestRatePayout"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "collateral"), "=", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "collateral"))) and rune_all_elements(rune_resolve_attr(self, "beforeTradeCollateralQuantity"), ">", rune_resolve_attr(self, "afterTradeCollateralQuantity"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "terminationDate"), "=", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "terminationDate"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "effectiveDate"), "=", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "effectiveDate")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
