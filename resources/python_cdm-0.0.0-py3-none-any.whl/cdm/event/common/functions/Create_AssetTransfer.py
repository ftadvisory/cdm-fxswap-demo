# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.Transfer import Transfer
from cdm.base.staticdata.party.functions.ExtractCounterpartyByRole import ExtractCounterpartyByRole
from cdm.base.math.functions.FilterQuantityByFinancialUnit import FilterQuantityByFinancialUnit
from cdm.observable.asset.PriceTypeEnum import PriceTypeEnum
from cdm.observable.asset.functions.FilterPrice import FilterPrice
from cdm.base.math.FinancialUnitEnum import FinancialUnitEnum
from cdm.event.common.CalculateTransferInstruction import CalculateTransferInstruction
from cdm.base.math.NonNegativeQuantity import NonNegativeQuantity

__all__ = ['Create_AssetTransfer']


@replaceable
def Create_AssetTransfer(instruction: CalculateTransferInstruction) -> Transfer:
    """
    Defines how Transfer that represents an exchange of asset based on an asset payout, should be constructed.
    
    Parameters 
    ----------
    instruction : CalculateTransferInstruction
    
    Returns
    -------
    transfer : Transfer
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rune_local_condition(_pre_registry)
    def condition_0_ShareUnits(self):
        def _then_fn0():
            return rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "quantity"), "unit"), "financialUnit"), "=", cdm.base.math.FinancialUnitEnum.FinancialUnitEnum.SHARE)
        
        def _else_fn0():
            return True
        
        return if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "quantity")), _then_fn0, _else_fn0)
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    def _then_fn0():
        return rune_resolve_attr(rune_resolve_attr(self, "instruction"), "quantity")
    
    def _else_fn0():
        return NonNegativeQuantity(value=rune_resolve_attr(rune_resolve_attr(self, "tradeQuantity"), "value"), unit=rune_resolve_attr(rune_resolve_attr(self, "tradeQuantity"), "unit"))
    
    def _then_fn2():
        return rune_resolve_attr(ExtractCounterpartyByRole(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), "trade"), "counterparty"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "assetPayout"), "payerReceiver"), "payer")), "partyReference")
    
    def _else_fn2():
        return True
    
    def _then_fn1():
        return rune_resolve_attr(ExtractCounterpartyByRole(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), "trade"), "counterparty"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "payerReceiver"), "payer")), "partyReference")
    
    def _else_fn1():
        return if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "assetPayout"), "payerReceiver"), "payer")), _then_fn2, _else_fn2)
    
    def _then_fn3():
        return rune_resolve_attr(ExtractCounterpartyByRole(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), "trade"), "counterparty"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "assetPayout"), "payerReceiver"), "receiver")), "partyReference")
    
    def _else_fn3():
        return True
    
    def _then_fn2():
        return rune_resolve_attr(ExtractCounterpartyByRole(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), "trade"), "counterparty"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "payerReceiver"), "receiver")), "partyReference")
    
    def _else_fn2():
        return if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "assetPayout"), "payerReceiver"), "receiver")), _then_fn3, _else_fn3)
    
    payout = (lambda item: rune_get_only_element(item))(rune_filter(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), "trade"), "product"), "economicTerms"), "payout"), lambda item: rune_attr_exists(rune_resolve_attr(item, "AssetPayout"))))
    assetPayout = rune_resolve_attr(rune_resolve_attr(self, "payout"), "AssetPayout")
    tradeQuantity = rune_get_only_element(FilterQuantityByFinancialUnit(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), "trade"), "tradeLot"), "priceQuantity"), "quantity"), cdm.base.math.FinancialUnitEnum.FinancialUnitEnum.SHARE))
    securityQuantity = if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "quantity")), _then_fn0, _else_fn0)
    securityPrice = FilterPrice(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), "trade"), "tradeLot"), "priceQuantity"), "price"), cdm.observable.asset.PriceTypeEnum.PriceTypeEnum.ASSET_PRICE, [], [])
    transfer = _get_rune_object('Transfer', 'quantity', NonNegativeQuantity(value=rune_resolve_attr(rune_resolve_attr(self, "securityQuantity"), "value"), unit=rune_resolve_attr(rune_resolve_attr(self, "securityQuantity"), "unit")))
    transfer.add_rune_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, transfer), 'asset'), 'Instrument'), 'Security'), 'identifier'), rune_resolve_deep_attr(self, "identifier"))
    transfer = set_rune_attr(rune_resolve_attr(self, 'transfer'), 'payerReceiver->payerPartyReference', if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "payerReceiver"), "payer")), _then_fn0, _else_fn0))
    transfer = set_rune_attr(rune_resolve_attr(self, 'transfer'), 'payerReceiver->receiverPartyReference', if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "payerReceiver"), "payer")), _then_fn1, _else_fn1))
    transfer = set_rune_attr(rune_resolve_attr(self, 'transfer'), 'settlementDate->adjustedDate', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "date"))
    transfer = set_rune_attr(rune_resolve_attr(self, 'transfer'), 'settlementOrigin', {rune_resolve_attr(self, "payout"): True})
    
    
    return transfer

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
