# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.functions.FilterOpenTradeStates import FilterOpenTradeStates
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.FilterClosedTradeStates import FilterClosedTradeStates

__all__ = ['Qualify_Roll']


@replaceable
def Qualify_Roll(businessEvent: BusinessEvent) -> bool:
    """
    Qualification of a roll event based on: (i) terminating a single existing trade, (ii) entering into a new trade with the same details as the old trade, except for the effective and termination date where the effective date. The roll qualification does not make any assumption on the resulting quantity which may change compared to the original trade (it may only be partially rolled). The price is also likely different as market conditions may have evolved.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    beforeEconomicterms = rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction")), "before"), "trade"), "product"), "economicTerms")
    openEconomicTerms = rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_get_only_element(FilterOpenTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"))), "trade"), "product"), "economicTerms")
    closedTradeState = FilterClosedTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"))
    is_event =  ((((((rune_attr_exists(rune_resolve_attr(self, "beforeEconomicterms")) and rune_attr_exists(rune_resolve_attr(self, "openEconomicTerms"))) and rune_all_elements(rune_count(rune_resolve_attr(self, "closedTradeState")), "=", 1)) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "payout"), "=", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "payout"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "collateral"), "=", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "collateral"))) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "effectiveDate"), "=", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "terminationDate"))) and rune_any_elements(rune_resolve_attr(rune_resolve_attr(self, "openEconomicTerms"), "terminationDate"), "<>", rune_resolve_attr(rune_resolve_attr(self, "beforeEconomicterms"), "terminationDate")))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
