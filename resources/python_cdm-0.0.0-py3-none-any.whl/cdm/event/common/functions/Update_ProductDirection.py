# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.staticdata.party.CounterpartyRoleEnum import CounterpartyRoleEnum
from cdm.product.template.NonTransferableProduct import NonTransferableProduct

__all__ = ['Update_ProductDirection']


@replaceable
def Update_ProductDirection(before: NonTransferableProduct, originalPayer: CounterpartyRoleEnum, originalReceiver: CounterpartyRoleEnum) -> NonTransferableProduct:
    """
    Flips the payer and receiver on a product (used when a Put Option is exercised).
    
    Parameters 
    ----------
    before : NonTransferableProduct
    
    originalPayer : CounterpartyRoleEnum
    
    originalReceiver : CounterpartyRoleEnum
    
    Returns
    -------
    after : NonTransferableProduct
    
    """
    self = inspect.currentframe()
    
    
    after =  rune_resolve_attr(self, "before")
    after = _get_rune_object('NonTransferableProduct', 'economicTerms', _get_rune_object('EconomicTerms', 'payout', _get_rune_object('Payout', 'OptionPayout', _get_rune_object('OptionPayout', 'payerReceiver', _get_rune_object('PayerReceiver', 'payer', rune_resolve_attr(self, "originalReceiver"))))))
    after = set_rune_attr(rune_resolve_attr(self, 'after'), 'economicTerms->payout->OptionPayout->payerReceiver->receiver', rune_resolve_attr(self, "originalPayer"))
    
    
    return after

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
