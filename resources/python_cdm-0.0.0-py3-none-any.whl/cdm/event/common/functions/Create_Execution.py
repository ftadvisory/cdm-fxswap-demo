# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.product.template.TradeLot import TradeLot
from cdm.event.position.PositionStatusEnum import PositionStatusEnum
from cdm.event.common.TradeState import TradeState
from cdm.event.common.ExecutionInstruction import ExecutionInstruction

__all__ = ['Create_Execution']


@replaceable
def Create_Execution(instruction: ExecutionInstruction) -> TradeState:
    """
    Specifies the function to compose an execution based on a minimum required set of inputs: product, quantity, parties, etc.
    
    Parameters 
    ----------
    instruction : ExecutionInstruction
    Instructions to be used as an input to the function
    
    Returns
    -------
    execution : TradeState
    
    """
    self = inspect.currentframe()
    
    
    execution = _get_rune_object('TradeState', 'trade', _get_rune_object('Trade', 'product', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "product")))
    execution.add_rune_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, execution), 'trade'), 'tradeLot'), TradeLot(priceQuantity=rune_resolve_attr(rune_resolve_attr(self, "instruction"), "priceQuantity"), lotIdentifier=rune_resolve_attr(rune_resolve_attr(self, "instruction"), "lotIdentifier")))
    execution.add_rune_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, execution), 'trade'), 'counterparty'), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "counterparty"))
    execution.add_rune_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, execution), 'trade'), 'ancillaryParty'), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "ancillaryParty"))
    execution.add_rune_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, execution), 'trade'), 'party'), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "parties"))
    execution.add_rune_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, execution), 'trade'), 'partyRole'), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "partyRoles"))
    execution = set_rune_attr(rune_resolve_attr(self, 'execution'), 'trade->executionDetails', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "executionDetails"))
    execution = set_rune_attr(rune_resolve_attr(self, 'execution'), 'trade->tradeDate', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeDate"))
    execution.add_rune_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, execution), 'trade'), 'tradeIdentifier'), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeIdentifier"))
    execution = set_rune_attr(rune_resolve_attr(self, 'execution'), 'state->positionState', cdm.event.position.PositionStatusEnum.PositionStatusEnum.EXECUTED)
    execution = set_rune_attr(rune_resolve_attr(self, 'execution'), 'trade->collateral', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "collateral"))
    
    
    return execution

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
