# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.product.asset.functions.FixedAmount import FixedAmount
from cdm.event.common.Transfer import Transfer
from cdm.base.staticdata.party.functions.ExtractCounterpartyByRole import ExtractCounterpartyByRole
from cdm.base.math.functions.FilterQuantityByFinancialUnit import FilterQuantityByFinancialUnit
from cdm.product.asset.functions.FloatingAmount import FloatingAmount
from cdm.event.common.TradeState import TradeState
from cdm.product.common.schedule.functions.CalculationPeriodRange import CalculationPeriodRange
from cdm.base.math.FinancialUnitEnum import FinancialUnitEnum
from cdm.event.common.Reset import Reset

__all__ = ['ResolveSecurityFinanceBillingAmount']


@replaceable
def ResolveSecurityFinanceBillingAmount(tradeState: TradeState, reset: Reset, recordStartDate: datetime.date, recordEndDate: datetime.date, transferDate: datetime.date) -> Transfer:
    """
    Calculates the billing amount for a Security Finance transaction.
    
    Parameters 
    ----------
    tradeState : TradeState
    
    reset : Reset
    
    recordStartDate : date
    
    recordEndDate : date
    
    transferDate : date
    
    Returns
    -------
    transfer : Transfer
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn1():
        return rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "marginPercentage")
    
    def _else_fn1():
        return 1.0
    
    def _then_fn0():
        return rune_resolve_attr(self, "valuationPercentage")
    
    def _else_fn0():
        return if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "marginPercentage")), _then_fn1, _else_fn1)
    
    def _then_fn2():
        return FloatingAmount(rune_resolve_attr(self, "interestRatePayout"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "reset"), "resetValue"), "value"), rune_resolve_attr(self, "billingQuantity"), rune_resolve_attr(self, "recordEndDate"), rune_resolve_attr(self, "calculationPeriodRange"))
    
    def _else_fn2():
        return True
    
    def _then_fn1():
        return FixedAmount(rune_resolve_attr(self, "interestRatePayout"), rune_resolve_attr(self, "billingQuantity"), rune_resolve_attr(self, "recordEndDate"), rune_resolve_attr(self, "calculationPeriodRange"))
    
    def _else_fn1():
        return if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "interestRatePayout"), "rateSpecification"), "FloatingRateSpecification")), _then_fn2, _else_fn2)
    
    def _then_fn2():
        return rune_resolve_attr(self, "payerPartyReference")
    
    def _else_fn2():
        return rune_resolve_attr(self, "receiverPartyReference")
    
    def _then_fn3():
        return rune_resolve_attr(self, "receiverPartyReference")
    
    def _else_fn3():
        return rune_resolve_attr(self, "payerPartyReference")
    
    securityQuantity = rune_get_only_element(FilterQuantityByFinancialUnit(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "tradeLot"), "priceQuantity"), "quantity"), cdm.base.math.FinancialUnitEnum.FinancialUnitEnum.SHARE))
    interestRatePayout = rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "product"), "economicTerms"), "payout"), "InterestRatePayout"))
    assetPayout = rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_deep_attr(self, "economicTerms"), "payout"), "AssetPayout"))
    collateral = rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "product"), "economicTerms"), "collateral")
    haircutPercentage = (1.0 - rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "haircutPercentage"))
    valuationPercentage = (1 / rune_resolve_attr(self, "haircutPercentage"))
    marginRatio = if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "collateral"), "collateralProvisions"), "eligibleCollateral")), "treatment"), "valuationTreatment"), "haircutPercentage")), _then_fn0, _else_fn0)
    billingQuantity = ((rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "reset"), "resetValue"), "value") * rune_resolve_attr(rune_resolve_attr(self, "securityQuantity"), "value")) * rune_resolve_attr(self, "marginRatio"))
    calculationPeriodRange = CalculationPeriodRange(rune_resolve_attr(self, "recordStartDate"), rune_resolve_attr(self, "recordEndDate"), [])
    performance = if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "interestRatePayout"), "rateSpecification"), "FixedRateSpecification")), _then_fn1, _else_fn1)
    payerPartyReference = rune_resolve_attr(ExtractCounterpartyByRole(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "counterparty"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "interestRatePayout"), "payerReceiver"), "payer")), "partyReference")
    receiverPartyReference = rune_resolve_attr(ExtractCounterpartyByRole(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "counterparty"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "interestRatePayout"), "payerReceiver"), "receiver")), "partyReference")
    transfer = _get_rune_object('Transfer', 'quantity', _get_rune_object('NonNegativeQuantity', 'value', rune_resolve_attr(self, "performance")))
    transfer = set_rune_attr(rune_resolve_attr(self, 'transfer'), 'quantity->unit->currency', rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "interestRatePayout"), "priceQuantity"), "quantitySchedule"), "unit"), "currency"))
    transfer = set_rune_attr(rune_resolve_attr(self, 'transfer'), 'payerReceiver->payerPartyReference', if_cond_fn(rune_all_elements(rune_resolve_attr(self, "performance"), ">=", 0), _then_fn0, _else_fn0))
    transfer = set_rune_attr(rune_resolve_attr(self, 'transfer'), 'payerReceiver->receiverPartyReference', if_cond_fn(rune_all_elements(rune_resolve_attr(self, "performance"), ">=", 0), _then_fn1, _else_fn1))
    transfer = set_rune_attr(rune_resolve_attr(self, 'transfer'), 'settlementDate->adjustedDate', rune_resolve_attr(self, "transferDate"))
    
    
    return transfer

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
