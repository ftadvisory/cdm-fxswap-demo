# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.Transfer import Transfer
from cdm.base.staticdata.party.functions.ExtractCounterpartyByRole import ExtractCounterpartyByRole
from cdm.base.math.functions.Abs import Abs
from cdm.product.asset.functions.ResolveEquityInitialPrice import ResolveEquityInitialPrice
from cdm.event.common.functions.EquityPerformance import EquityPerformance
from cdm.event.common.TradeState import TradeState
from cdm.event.common.functions.ResolveCashSettlementDate import ResolveCashSettlementDate

__all__ = ['EquityCashSettlementAmount']


@replaceable
def EquityCashSettlementAmount(tradeState: TradeState, date: datetime.date) -> Transfer:
    """
    Represents Part 1 Section 12 of the 2018 ISDA CDM Equity Confirmation for Security Equity Swap, Para 72. 'Equity Cash Settlement Amount' means, in respect of an Equity Cash Settlement Date, an amount in the Settlement Currency determined by the Calculation Agent as of the Equity Valuation Date to which the Equity Cash Settlement Amount relates, pursuant to the following formula: Equity Cash Settlement Amount = ABS(Rate Of Return) * Equity Notional Amount.
    
    Parameters 
    ----------
    tradeState : TradeState
    
    date : date
    
    Returns
    -------
    equityCashSettlementAmount : Transfer
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn0():
        return rune_resolve_attr(self, "payer")
    
    def _else_fn0():
        return rune_resolve_attr(self, "receiver")
    
    def _then_fn1():
        return rune_resolve_attr(self, "receiver")
    
    def _else_fn1():
        return rune_resolve_attr(self, "payer")
    
    payout = (lambda item: rune_get_only_element(item))(rune_filter(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "product"), "economicTerms"), "payout"), lambda item: rune_attr_exists(rune_resolve_attr(item, "PerformancePayout"))))
    equityPerformancePayout = rune_resolve_attr(rune_resolve_attr(self, "payout"), "PerformancePayout")
    equityPerformance = EquityPerformance(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "resetHistory")), "resetValue"), rune_resolve_attr(self, "date"))
    payer = rune_resolve_attr(ExtractCounterpartyByRole(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "counterparty"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "equityPerformancePayout"), "payerReceiver"), "payer")), "partyReference")
    receiver = rune_resolve_attr(ExtractCounterpartyByRole(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "counterparty"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "equityPerformancePayout"), "payerReceiver"), "receiver")), "partyReference")
    equityCashSettlementAmount = _get_rune_object('Transfer', 'quantity', _get_rune_object('NonNegativeQuantity', 'value', Abs(rune_resolve_attr(self, "equityPerformance"))))
    equityCashSettlementAmount = set_rune_attr(rune_resolve_attr(self, 'equityCashSettlementAmount'), 'quantity->unit->currency', rune_resolve_attr(rune_resolve_attr(ResolveEquityInitialPrice(rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade"), "tradeLot")), "priceQuantity"), "price")), "unit"), "currency"))
    equityCashSettlementAmount = set_rune_attr(rune_resolve_attr(self, 'equityCashSettlementAmount'), 'payerReceiver->payerPartyReference', if_cond_fn(rune_all_elements(rune_resolve_attr(self, "equityPerformance"), ">=", 0), _then_fn0, _else_fn0))
    equityCashSettlementAmount = set_rune_attr(rune_resolve_attr(self, 'equityCashSettlementAmount'), 'payerReceiver->receiverPartyReference', if_cond_fn(rune_all_elements(rune_resolve_attr(self, "equityPerformance"), ">=", 0), _then_fn1, _else_fn1))
    equityCashSettlementAmount = set_rune_attr(rune_resolve_attr(self, 'equityCashSettlementAmount'), 'settlementDate->adjustedDate', ResolveCashSettlementDate(rune_resolve_attr(self, "tradeState")))
    equityCashSettlementAmount = set_rune_attr(rune_resolve_attr(self, 'equityCashSettlementAmount'), 'settlementOrigin', {rune_resolve_attr(self, "payout"): True})
    
    
    return equityCashSettlementAmount

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
