# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.Transfer import Transfer

__all__ = ['FilterSecurityTransfers']


@replaceable
def FilterSecurityTransfers(transfers: list[Transfer] | None) -> Transfer:
    """
    
    Parameters 
    ----------
    transfers : Transfer
    
    Returns
    -------
    securityTransfers : Transfer
    
    """
    self = inspect.currentframe()
    
    
    securityTransfers = rune_filter(rune_resolve_attr(self, "transfers"), lambda item: rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(item, "asset"), "Instrument"), "Security")))
    
    
    return securityTransfers

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
