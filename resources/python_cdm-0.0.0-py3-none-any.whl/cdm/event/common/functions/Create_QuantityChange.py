# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.product.template.TradeLot import TradeLot
from cdm.product.common.settlement.functions.UpdateAmountForEachMatchingQuantity import UpdateAmountForEachMatchingQuantity
from cdm.event.position.PositionStatusEnum import PositionStatusEnum
from cdm.observable.asset.PriceTypeEnum import PriceTypeEnum
from cdm.event.common.QuantityChangeInstruction import QuantityChangeInstruction
from cdm.base.math.QuantityChangeDirectionEnum import QuantityChangeDirectionEnum
from cdm.event.common.TradeState import TradeState
from cdm.product.template.functions.FilterTradeLot import FilterTradeLot
from cdm.product.template.functions.AddTradeLot import AddTradeLot
from cdm.product.template.functions.ReplaceTradeLot import ReplaceTradeLot

__all__ = ['Create_QuantityChange']


@replaceable
def Create_QuantityChange(instruction: QuantityChangeInstruction, tradeState: TradeState) -> TradeState:
    """
    A specification of the inputs, outputs and constraints when calculating the after state of a Quantity Change Primitive Event
    
    Parameters 
    ----------
    instruction : QuantityChangeInstruction
    
    tradeState : TradeState
    
    Returns
    -------
    quantityChange : TradeState
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rune_local_condition(_pre_registry)
    def condition_0_CashPriceOnly(self):
        """
        Only termination where the termination price is specified as a cash price is supported for now.
        """
        def _then_fn0():
            return rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "change"), "price"), "priceType"), "=", cdm.observable.asset.PriceTypeEnum.PriceTypeEnum.CASH_PRICE)
        
        def _else_fn0():
            return True
        
        return if_cond_fn((rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "direction"), "=", cdm.base.math.QuantityChangeDirectionEnum.QuantityChangeDirectionEnum.DECREASE) and rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "change"), "price"))), _then_fn0, _else_fn0)
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    def _then_fn0():
        return FilterTradeLot(rune_resolve_attr(rune_resolve_attr(self, "trade"), "tradeLot"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "lotIdentifier"))
    
    def _else_fn0():
        return rune_get_only_element(rune_resolve_attr(rune_resolve_attr(self, "trade"), "tradeLot"))
    
    def _then_fn1():
        return rune_resolve_attr(rune_resolve_attr(self, "instruction"), "change")
    
    def _else_fn1():
        return UpdateAmountForEachMatchingQuantity(rune_resolve_attr(rune_resolve_attr(self, "tradeLot"), "priceQuantity"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "change"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "direction"))
    
    def _then_fn2():
        return rune_resolve_attr(AddTradeLot(rune_resolve_attr(self, "trade"), TradeLot(lotIdentifier=rune_resolve_attr(rune_resolve_attr(self, "instruction"), "lotIdentifier"), priceQuantity=rune_resolve_attr(self, "newPriceQuantity"))), "tradeLot")
    
    def _else_fn2():
        return ReplaceTradeLot(rune_resolve_attr(rune_resolve_attr(self, "trade"), "tradeLot"), TradeLot(lotIdentifier=rune_resolve_attr(rune_resolve_attr(self, "instruction"), "lotIdentifier"), priceQuantity=rune_resolve_attr(self, "newPriceQuantity")))
    
    def _then_fn3():
        return cdm.event.position.PositionStatusEnum.PositionStatusEnum.CLOSED
    
    def _else_fn3():
        return True
    
    trade = rune_resolve_attr(rune_resolve_attr(self, "tradeState"), "trade")
    tradeLotExists = rune_attr_exists(FilterTradeLot(rune_resolve_attr(rune_resolve_attr(self, "trade"), "tradeLot"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "lotIdentifier")))
    tradeLot = if_cond_fn(rune_resolve_attr(self, "tradeLotExists"), _then_fn0, _else_fn0)
    newPriceQuantity = if_cond_fn((rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "direction"), "=", cdm.base.math.QuantityChangeDirectionEnum.QuantityChangeDirectionEnum.INCREASE) and rune_all_elements(rune_resolve_attr(self, "tradeLotExists"), "=", False)), _then_fn1, _else_fn1)
    newTradeLots = if_cond_fn((rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "direction"), "=", cdm.base.math.QuantityChangeDirectionEnum.QuantityChangeDirectionEnum.INCREASE) and rune_all_elements(rune_resolve_attr(self, "tradeLotExists"), "=", False)), _then_fn2, _else_fn2)
    quantityChange =  rune_resolve_attr(self, "tradeState")
    quantityChange = _get_rune_object('TradeState', 'trade', _get_rune_object('Trade', 'product', rune_resolve_attr(rune_resolve_attr(self, "trade"), "product")))
    quantityChange = set_rune_attr(rune_resolve_attr(self, 'quantityChange'), 'trade->tradeLot', rune_resolve_attr(self, "newTradeLots"))
    quantityChange = set_rune_attr(rune_resolve_attr(self, 'quantityChange'), 'trade->counterparty', rune_resolve_attr(rune_resolve_attr(self, "trade"), "counterparty"))
    quantityChange = set_rune_attr(rune_resolve_attr(self, 'quantityChange'), 'trade->ancillaryParty', rune_resolve_attr(rune_resolve_attr(self, "trade"), "ancillaryParty"))
    quantityChange = set_rune_attr(rune_resolve_attr(self, 'quantityChange'), 'trade->adjustment', rune_resolve_attr(rune_resolve_attr(self, "trade"), "adjustment"))
    quantityChange = set_rune_attr(rune_resolve_attr(self, 'quantityChange'), 'state->positionState', if_cond_fn(rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "newTradeLots"), "priceQuantity"), "quantity"), "value"), "=", 0), _then_fn6, _else_fn6))
    
    
    return quantityChange

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
