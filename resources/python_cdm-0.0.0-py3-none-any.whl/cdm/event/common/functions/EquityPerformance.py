# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.functions.RateOfReturn import RateOfReturn
from cdm.event.common.functions.EquityNotionalAmount import EquityNotionalAmount
from cdm.event.common.Trade import Trade
from cdm.observable.asset.Price import Price
from cdm.product.asset.functions.ResolvePerformancePeriodStartPrice import ResolvePerformancePeriodStartPrice

__all__ = ['EquityPerformance']


@replaceable
def EquityPerformance(trade: Trade, observation: Price, date: datetime.date) -> Decimal:
    """
    Part 1 Section 12 of the 2018 ISDA CDM Equity Confirmation for Security Equity Swap, Para 75. 'Equity Performance' means, in respect of an Equity Cash Settlement Date, an amount in the Settlement Currency determined by the Calculation Agent as of the Equity Valuation Date to which the Equity Cash Settlement Amount relates, pursuant to the following formula: Equity Performance = (Rate Of Return)  Equity Notional Amount.
    
    Parameters 
    ----------
    trade : Trade
    
    observation : Price
    
    date : date
    
    Returns
    -------
    equityPerformance : number
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rune_local_condition(_pre_registry)
    def condition_0_PriceReturnTermsExists(self):
        return rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "trade"), "product"), "economicTerms"), "payout"), "PerformancePayout"), "returnTerms"), "priceReturnTerms"))
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    performancePayout = rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "trade"), "product"), "economicTerms"), "payout"), "PerformancePayout"))
    periodStartPrice = ResolvePerformancePeriodStartPrice(rune_resolve_attr(self, "performancePayout"), rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(self, "trade"), "tradeLot")), "priceQuantity"), "price"), rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "trade"), "tradeLot"), "priceQuantity"), "observable")), rune_resolve_attr(self, "date"))
    periodEndPrice = rune_resolve_attr(self, "observation")
    numberOfSecurities = (rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "performancePayout"), "priceQuantity"), "quantitySchedule"), "value") / rune_resolve_attr(rune_resolve_attr(self, "periodStartPrice"), "value"))
    rateOfReturn = RateOfReturn(rune_resolve_attr(self, "periodStartPrice"), rune_resolve_attr(self, "periodEndPrice"))
    notionalAmount = EquityNotionalAmount(rune_resolve_attr(self, "numberOfSecurities"), rune_resolve_attr(self, "periodEndPrice"))
    equityPerformance =  (rune_resolve_attr(self, "rateOfReturn") * rune_resolve_attr(self, "notionalAmount"))
    
    
    return equityPerformance

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
