# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.Transfer import Transfer
from cdm.event.common.functions.EquityCashSettlementAmount import EquityCashSettlementAmount
from cdm.event.common.functions.InterestCashSettlementAmount import InterestCashSettlementAmount
from cdm.event.common.functions.SecurityFinanceCashSettlementAmount import SecurityFinanceCashSettlementAmount
from cdm.event.common.CalculateTransferInstruction import CalculateTransferInstruction

__all__ = ['ResolveTransfer']


@replaceable
def ResolveTransfer(instruction: CalculateTransferInstruction) -> Transfer:
    """
    Defines how to calculate the amount due to be transferred after a Reset Event.
    
    Parameters 
    ----------
    instruction : CalculateTransferInstruction
    
    Returns
    -------
    transfer : Transfer
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn2():
        return InterestCashSettlementAmount(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), rune_resolve_attr(self, "payout"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "resets"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "date"))
    
    def _else_fn2():
        return True
    
    def _then_fn1():
        return EquityCashSettlementAmount(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "date"))
    
    def _else_fn1():
        return if_cond_fn((rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "payout"), "InterestRatePayout"), "rateSpecification"), "FloatingRateSpecification")) or rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "payout"), "InterestRatePayout"), "rateSpecification"), "FixedRateSpecification"))), _then_fn2, _else_fn2)
    
    def _then_fn0():
        return SecurityFinanceCashSettlementAmount(rune_resolve_attr(rune_resolve_attr(self, "instruction"), "tradeState"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "date"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "quantity"), rune_resolve_attr(rune_resolve_attr(self, "instruction"), "payerReceiver"))
    
    def _else_fn0():
        return if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(self, "payout"), "PerformancePayout")), _then_fn1, _else_fn1)
    
    payout = rune_resolve_attr(rune_resolve_attr(self, "instruction"), "payout")
    transfer =  if_cond_fn(rune_attr_exists(rune_resolve_attr(rune_resolve_attr(self, "payout"), "AssetPayout")), _then_fn0, _else_fn0)
    transfer = _get_rune_object('Transfer', 'settlementDate', _get_rune_object('AdjustableOrAdjustedOrRelativeDate', 'adjustedDate', rune_resolve_attr(rune_resolve_attr(self, "instruction"), "date")))
    
    
    return transfer

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
