# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['AffirmationStatusEnum']

class AffirmationStatusEnum(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    """
    Enumeration for the different types of affirmation status.
    """
    AFFIRMED = "Affirmed"
    UNAFFIRMED = "Unaffirmed"
