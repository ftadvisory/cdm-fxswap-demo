# pylint: disable=missing-module-docstring, invalid-name, line-too-long
from enum import Enum
import rune.runtime.metadata

__all__ = ['ConfirmationStatusEnum']

class ConfirmationStatusEnum(rune.runtime.metadata.EnumWithMetaMixin, Enum):
    """
    Enumeration for the different types of confirmation status.
    """
    CONFIRMED = "Confirmed"
    UNCONFIRMED = "Unconfirmed"
