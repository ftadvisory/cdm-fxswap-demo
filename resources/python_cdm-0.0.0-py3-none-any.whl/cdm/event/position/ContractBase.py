# pylint: disable=unused-import
from cdm._bundle import cdm_event_position_ContractBase as ContractBase

# EOF
