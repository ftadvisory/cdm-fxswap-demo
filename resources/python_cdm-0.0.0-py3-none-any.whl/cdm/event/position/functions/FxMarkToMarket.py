# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.base.math.functions.FilterQuantityByCurrency import FilterQuantityByCurrency
from cdm.event.common.Trade import Trade
from cdm.event.position.functions.InterpolateForwardRate import InterpolateForwardRate

__all__ = ['FxMarkToMarket']


@replaceable
def FxMarkToMarket(trade: Trade) -> Decimal:
    """
    Representation of sample mark to market calculation provided by a member firm.
    
    Parameters 
    ----------
    trade : Trade
    
    Returns
    -------
    value : number
    
    """
    _pre_registry = {}
    self = inspect.currentframe()
    
    # conditions
    
    @rune_local_condition(_pre_registry)
    def condition_0_SettlementPayoutExists(self):
        """
        The settlementPayout on the contract must exist.
        """
        return rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "trade"), "product"), "economicTerms"), "payout"), "SettlementPayout"))
    # Execute all registered conditions
    execute_local_conditions(_pre_registry, 'Pre-condition')
    
    settlementPayout = rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "trade"), "product"), "economicTerms"), "payout"), "SettlementPayout"))
    quotedCurrency = rune_get_only_element(set(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "trade"), "tradeLot"), "priceQuantity"), "price"), "unit"), "currency")))
    baseCurrency = rune_get_only_element(set(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "trade"), "tradeLot"), "priceQuantity"), "price"), "perUnitOf"), "currency")))
    quantities = rune_resolve_attr(rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(self, "trade"), "tradeLot")), "priceQuantity"), "quantity")
    quotedQuantity = rune_resolve_attr(rune_get_only_element(FilterQuantityByCurrency(rune_resolve_attr(self, "quantities"), rune_resolve_attr(self, "quotedCurrency"))), "value")
    baseQuantity = rune_resolve_attr(rune_get_only_element(FilterQuantityByCurrency(rune_resolve_attr(self, "quantities"), rune_resolve_attr(self, "baseCurrency"))), "value")
    interpolatedRate = InterpolateForwardRate(rune_resolve_attr(self, "settlementPayout"))
    value =  (((rune_resolve_attr(self, "quotedQuantity") / rune_resolve_attr(self, "interpolatedRate")) - rune_resolve_attr(self, "baseQuantity")) * rune_resolve_attr(self, "interpolatedRate"))
    
    
    return value

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
