# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.workflow.Workflow import Workflow
from cdm.event.workflow.WorkflowStep import WorkflowStep

__all__ = ['Create_Workflow']


@replaceable
def Create_Workflow(steps: list[WorkflowStep]) -> Workflow:
    """
    Function to create a Workflow from a list of WorkflowStep.
    
    Parameters 
    ----------
    steps : WorkflowStep
    
    Returns
    -------
    workflow : Workflow
    
    """
    self = inspect.currentframe()
    
    
    workflow = rune_resolve_attr(self, "steps")
    
    
    return workflow

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
