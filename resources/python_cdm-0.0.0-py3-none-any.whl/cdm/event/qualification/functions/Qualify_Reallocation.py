# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.functions.FilterOpenTradeStates import FilterOpenTradeStates
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.functions.FilterClosedTradeStates import FilterClosedTradeStates
from cdm.event.common.EventIntentEnum import EventIntentEnum
from cdm.event.common.functions.QuantityDecreased import QuantityDecreased

__all__ = ['Qualify_Reallocation']


@replaceable
def Qualify_Reallocation(businessEvent: BusinessEvent) -> bool:
    """
    The qualification of a reallocation event from the fact that (i) a quantity change primitive exists, (ii) a split primitive exists, and (iii) the intent is Reallocation.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    beforeTradeState = rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"), "before"))
    closedTradeStates = FilterClosedTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"))
    openTradeStates = FilterOpenTradeStates(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"))
    is_event =  ((((rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "intent"), "=", cdm.event.common.EventIntentEnum.EventIntentEnum.REALLOCATION) and rune_all_elements(rune_count(rune_resolve_attr(self, "closedTradeStates")), "=", 0)) and rune_all_elements(rune_count(rune_resolve_attr(self, "openTradeStates")), "=", 2)) and rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"), "primitiveInstruction"), "split"))) and rune_all_elements(list(map(lambda item: ((rune_any_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(item, "trade"), "counterparty"), "partyReference"), "<>", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "beforeTradeState"), "trade"), "counterparty"), "partyReference")) and rune_any_elements(rune_resolve_attr(rune_resolve_attr(item, "trade"), "tradeIdentifier"), "<>", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "beforeTradeState"), "trade"), "tradeIdentifier"))) or ((rune_all_elements(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(item, "trade"), "counterparty"), "partyReference"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "beforeTradeState"), "trade"), "counterparty"), "partyReference")) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(item, "trade"), "tradeIdentifier"), "=", rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "beforeTradeState"), "trade"), "tradeIdentifier"))) and QuantityDecreased(rune_resolve_attr(self, "beforeTradeState"), [item]))), rune_resolve_attr(self, "openTradeStates"))), "=", True))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
