# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.observable.asset.PriceTypeEnum import PriceTypeEnum
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.observable.asset.functions.FilterPrice import FilterPrice
from cdm.base.math.ArithmeticOperationEnum import ArithmeticOperationEnum
from cdm.event.common.EventIntentEnum import EventIntentEnum

__all__ = ['Qualify_IndexTransition']


@replaceable
def Qualify_IndexTransition(businessEvent: BusinessEvent) -> bool:
    """
    The qualification of an index transition event based on (i) adjustment spread applied and (ii) floating rate index changed.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    def _then_fn0():
        return rune_any_elements(rune_resolve_attr(rune_resolve_attr(self, "spread"), "value"), "<>", 0)
    
    def _else_fn0():
        return True
    
    after = rune_resolve_attr(rune_get_only_element(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after")), "trade")
    before = rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"), "before"), "trade")
    floatingRateIndexChanged = (rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "before"), "tradeLot"), "priceQuantity"), "observable"), "Index"), "InterestRateIndex")) and rune_disjoint(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "before"), "tradeLot"), "priceQuantity"), "observable"), "Index"), "InterestRateIndex"), rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "after"), "tradeLot"), "priceQuantity"), "observable"), "Index"), "InterestRateIndex")))
    spread = FilterPrice(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "after"), "tradeLot"), "priceQuantity"), "price"), cdm.observable.asset.PriceTypeEnum.PriceTypeEnum.INTEREST_RATE, [cdm.base.math.ArithmeticOperationEnum.ArithmeticOperationEnum.ADD, cdm.base.math.ArithmeticOperationEnum.ArithmeticOperationEnum.SUBTRACT], [])
    adjustmentSpreadAdded = if_cond_fn(rune_attr_exists(rune_resolve_attr(self, "spread")), _then_fn0, _else_fn0)
    is_event =  ((rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "intent"), "=", cdm.event.common.EventIntentEnum.EventIntentEnum.INDEX_TRANSITION) and rune_all_elements(rune_resolve_attr(self, "floatingRateIndexChanged"), "=", True)) and rune_all_elements(rune_resolve_attr(self, "adjustmentSpreadAdded"), "=", True))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
