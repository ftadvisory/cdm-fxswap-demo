# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.functions.TransfersForDate import TransfersForDate
from cdm.event.common.BusinessEvent import BusinessEvent
from cdm.event.common.EventIntentEnum import EventIntentEnum
from cdm.event.common.functions.QuantityDecreasedToZero import QuantityDecreasedToZero

__all__ = ['Qualify_Renegotiation']


@replaceable
def Qualify_Renegotiation(businessEvent: BusinessEvent) -> bool:
    """
    The qualification of a renegotiation event from the fact that (i) the intent is Renegotiation when specified, and (ii) the associated primitives instructions are the TermsChange, QuantityChange and the cash transfer.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    transfers = TransfersForDate(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"), "transferHistory"), "transfer"), rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "eventDate"))
    is_event =  (((((not rune_attr_exists(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "intent"))) or rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "intent"), "=", cdm.event.common.EventIntentEnum.EventIntentEnum.CONTRACT_TERMS_AMENDMENT)) and rune_all_elements(list(map(lambda item: (rune_check_one_of(self, rune_resolve_attr(rune_resolve_attr(item, "primitiveInstruction"), "termsChange")) or rune_check_one_of(self, rune_resolve_attr(rune_resolve_attr(item, "primitiveInstruction"), "termsChange"))), rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"))), "=", True)) and rune_all_elements(QuantityDecreasedToZero(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"), "before"), rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after")), "=", False)) and (not rune_attr_exists(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"), "state"), "closedState"))))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
