# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
import sys
import datetime
import inspect
from decimal import Decimal
from rune.runtime.base_data_class import BaseDataClass
from rune.runtime.metadata import *
from rune.runtime.utils import *
from rune.runtime.conditions import *
from rune.runtime.func_proxy import *
from cdm.event.common.BusinessEvent import BusinessEvent

__all__ = ['Qualify_Reset']


@replaceable
def Qualify_Reset(businessEvent: BusinessEvent) -> bool:
    """
    The qualification of a reset event from the fact that the only primitive is the reset.
    
    Parameters 
    ----------
    businessEvent : BusinessEvent
    
    Returns
    -------
    is_event : boolean
    
    """
    self = inspect.currentframe()
    
    
    beforeTradeState = rune_get_only_element(rune_resolve_attr(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "instruction"), "before"))
    afterTradeState = rune_get_only_element(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after"))
    is_event =  ((rune_all_elements(rune_count(rune_resolve_attr(rune_resolve_attr(self, "businessEvent"), "after")), "=", 1) and rune_all_elements(rune_resolve_attr(rune_resolve_attr(self, "beforeTradeState"), "trade"), "=", rune_resolve_attr(rune_resolve_attr(self, "afterTradeState"), "trade"))) and rune_all_elements((rune_count(rune_resolve_attr(rune_resolve_attr(self, "beforeTradeState"), "resetHistory")) + 1), "=", rune_count(rune_resolve_attr(rune_resolve_attr(self, "afterTradeState"), "resetHistory"))))
    
    
    return is_event

sys.modules[__name__].__class__ = create_module_attr_guardian(sys.modules[__name__].__class__)
